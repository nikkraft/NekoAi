package com.neko.ai

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.webkit.CookieManager
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import org.json.JSONObject

const val START_URL = "https://arena.ai/"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContent { NekoTheme { NekoWeb() } }
    }
}

@Composable
fun NekoTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val ctx = LocalContext.current
    val scheme = when {
        Build.VERSION.SDK_INT >= 31 -> if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> darkColorScheme()
        else -> lightColorScheme()
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

private fun hex(c: Color) = String.format("#%06X", 0xFFFFFF and c.toArgb())

private fun rootVars(cs: ColorScheme): String {
    val m = linkedMapOf(
        "primary" to cs.primary,
        "on-primary" to cs.onPrimary,
        "primary-container" to cs.primaryContainer,
        "on-primary-container" to cs.onPrimaryContainer,
        "secondary" to cs.secondary,
        "background" to cs.background,
        "surface" to cs.surface,
        "on-surface" to cs.onSurface,
        "surface-variant" to cs.surfaceVariant,
        "on-surface-variant" to cs.onSurfaceVariant,
        "surface-container" to cs.surfaceContainer,
        "surface-container-high" to cs.surfaceContainerHigh,
        "outline" to cs.outline,
        "error" to cs.error
    )
    return ":root{" + m.entries.joinToString("") { "--neko-${it.key}:${hex(it.value)};" } + "}"
}

private fun buildJs(css: String, js: String, dark: Boolean): String =
    "(function(){try{window.__NEKO_CSS=" + JSONObject.quote(css) +
        ";window.__NEKO_DARK=" + dark + ";" + js + "\n}catch(e){}})();"

@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun NekoWeb() {
    val ctx = LocalContext.current
    val dark = isSystemInDarkTheme()
    val cs = MaterialTheme.colorScheme

    val skinCss = remember { ctx.assets.open("skin.css").bufferedReader().use { it.readText() } }
    val skinJs = remember { ctx.assets.open("skin.js").bufferedReader().use { it.readText() } }
    val inject = remember(cs, dark) { buildJs(rootVars(cs) + "\n" + skinCss, skinJs, dark) }
    val latestInject by rememberUpdatedState(inject)

    var web by remember { mutableStateOf<WebView?>(null) }
    var progress by remember { mutableIntStateOf(0) }
    var canBack by remember { mutableStateOf(false) }
    var loadedOnce by remember { mutableStateOf(false) }
    var failure by remember { mutableStateOf<String?>(null) }
    var chooser by remember { mutableStateOf<ValueCallback<Array<Uri>>?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        chooser?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res.resultCode, res.data))
        chooser = null
    }

    LaunchedEffect(inject) { web?.evaluateJavascript(inject, null) }
    BackHandler(enabled = canBack) { web?.goBack() }

    Scaffold(
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        topBar = {
            TopAppBar(
                title = { Text("NekoAI") },
                actions = {
                    IconButton(onClick = { web?.reload() }) { Icon(Icons.Default.Refresh, "Обновить") }
                }
            )
        }
    ) { pad ->
        Box(
            Modifier
                .padding(pad)
                .fillMaxSize()
                .navigationBarsPadding()
                .imePadding()
        ) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { c ->
                    WebView(c).apply {
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        CookieManager.getInstance().setAcceptCookie(true)
                        CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                        webViewClient = object : WebViewClient() {
                            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                                val u = r.url
                                if (u.scheme == "http" || u.scheme == "https") return false
                                try {
                                    c.startActivity(Intent(Intent.ACTION_VIEW, u).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                                } catch (e: Exception) {
                                }
                                return true
                            }

                            override fun onPageStarted(v: WebView, url: String?, favicon: Bitmap?) {
                                failure = null
                                v.evaluateJavascript(latestInject, null)
                            }

                            override fun onPageFinished(v: WebView, url: String?) {
                                v.evaluateJavascript(latestInject, null)
                                loadedOnce = true
                                canBack = v.canGoBack()
                            }

                            override fun doUpdateVisitedHistory(v: WebView, url: String?, isReload: Boolean) {
                                canBack = v.canGoBack()
                            }

                            override fun onReceivedError(v: WebView, r: WebResourceRequest, e: WebResourceError) {
                                if (r.isForMainFrame) failure = e.description?.toString() ?: "Нет соединения"
                            }
                        }
                        webChromeClient = object : WebChromeClient() {
                            override fun onProgressChanged(v: WebView, p: Int) {
                                progress = p
                            }

                            override fun onShowFileChooser(
                                v: WebView,
                                cb: ValueCallback<Array<Uri>>,
                                params: FileChooserParams
                            ): Boolean {
                                chooser?.onReceiveValue(null)
                                chooser = cb
                                return try {
                                    picker.launch(params.createIntent())
                                    true
                                } catch (e: Exception) {
                                    chooser = null
                                    false
                                }
                            }
                        }
                        loadUrl(START_URL)
                    }
                },
                update = {
                    web = it
                    it.setBackgroundColor(cs.background.toArgb())
                }
            )

            if (progress in 1..99) {
                LinearProgressIndicator(
                    progress = { progress / 100f },
                    modifier = Modifier.fillMaxWidth().align(Alignment.TopCenter)
                )
            }
            if (!loadedOnce && failure == null) Splash()
            failure?.let { msg ->
                ErrorView(msg) {
                    failure = null
                    web?.reload()
                }
            }
        }
    }
}

@Composable
private fun Logo() {
    Box(
        Modifier
            .size(96.dp)
            .clip(RoundedCornerShape(28.dp))
            .background(Color(0xFF3B2E8F)),
        contentAlignment = Alignment.Center
    ) {
        Image(painterResource(R.drawable.ic_launcher_foreground), null, Modifier.size(96.dp))
    }
}

@Composable
private fun Splash() {
    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Logo()
        Spacer(Modifier.height(16.dp))
        Text("NekoAI", style = MaterialTheme.typography.headlineMedium)
    }
}

@Composable
private fun ErrorView(msg: String, onRetry: () -> Unit) {
    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Logo()
        Spacer(Modifier.height(16.dp))
        Text("Не удалось загрузить сайт", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(4.dp))
        Text(
            msg,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(16.dp))
        Button(onClick = onRetry) { Text("Повторить") }
    }
}
