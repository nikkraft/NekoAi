package com.neko.arena

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

sealed class Block {
    data class Code(val lang: String, val code: String) : Block()
    data class Heading(val level: Int, val text: String) : Block()
    data class Item(val marker: String, val indent: Int, val text: String) : Block()
    data class Quote(val text: String) : Block()
    data class Para(val text: String) : Block()
    object Rule : Block()
}

private val RE_HEAD = Regex("^(#{1,6})\\s+(.*)$")
private val RE_ULIST = Regex("^[-*+]\\s+(.*)$")
private val RE_OLIST = Regex("^(\\d{1,3})[.)]\\s+(.*)$")
private val RE_RULE = Regex("^([-*_])(\\s*\\1){2,}\\s*$")
private val RE_LINK = Regex("\\[([^\\]]+)\\]\\(([^)\\s]+)\\)")
private val RE_SEP = Regex("^:?-+:?$")

fun parseBlocks(src: String): List<Block> {
    val out = mutableListOf<Block>()
    val lines = src.split("\n")
    val para = StringBuilder()
    fun flush() {
        if (para.isNotEmpty()) {
            out += Block.Para(para.toString().trimEnd())
            para.clear()
        }
    }
    var i = 0
    while (i < lines.size) {
        val line = lines[i].trimEnd('\r')
        val t = line.trimStart()
        if (t.startsWith("```")) {
            flush()
            val lang = t.removePrefix("```").trim()
            val code = StringBuilder()
            i++
            while (i < lines.size && !lines[i].trimStart().startsWith("```")) {
                code.append(lines[i].trimEnd('\r')).append('\n')
                i++
            }
            out += Block.Code(lang, code.toString().trimEnd('\n'))
        } else if (t.isEmpty()) {
            flush()
        } else if (t.startsWith("|")) {
            flush()
            val rows = mutableListOf<String>()
            while (i < lines.size && lines[i].trimStart().startsWith("|")) {
                rows += lines[i].trim()
                i++
            }
            i--
            out += Block.Code("таблица", formatTable(rows))
        } else if (RE_RULE.matches(t)) {
            flush()
            out += Block.Rule
        } else {
            val h = RE_HEAD.matchEntire(t)
            val ul = RE_ULIST.matchEntire(t)
            val ol = RE_OLIST.matchEntire(t)
            val indent = ((line.length - t.length) / 2).coerceIn(0, 3)
            when {
                h != null -> {
                    flush()
                    out += Block.Heading(h.groupValues[1].length, h.groupValues[2])
                }
                ul != null -> {
                    flush()
                    out += Block.Item("•", indent, ul.groupValues[1])
                }
                ol != null -> {
                    flush()
                    out += Block.Item(ol.groupValues[1] + ".", indent, ol.groupValues[2])
                }
                t.startsWith(">") -> {
                    flush()
                    out += Block.Quote(t.removePrefix(">").trim())
                }
                else -> {
                    if (para.isNotEmpty()) para.append('\n')
                    para.append(line)
                }
            }
        }
        i++
    }
    flush()
    return out
}

private fun formatTable(rows: List<String>): String {
    val cells = rows.map { r -> r.trim().trim('|').split("|").map { it.trim() } }
    val body = cells.filterNot { row -> row.isNotEmpty() && row.all { RE_SEP.matches(it) } }
    if (body.isEmpty()) return rows.joinToString("\n")
    val n = body.maxOf { it.size }
    val w = IntArray(n) { c -> body.maxOf { r -> r.getOrNull(c)?.length ?: 0 } }
    fun fmt(r: List<String>) = (0 until n).joinToString("  ") { c -> (r.getOrNull(c) ?: "").padEnd(w[c]) }.trimEnd()
    val sb = StringBuilder()
    body.forEachIndexed { idx, r ->
        sb.append(fmt(r)).append('\n')
        if (idx == 0 && body.size > 1) sb.append(w.joinToString("  ") { "─".repeat(maxOf(it, 1)) }).append('\n')
    }
    return sb.toString().trimEnd('\n')
}

fun inlineMd(s: String, codeBg: Color, linkColor: Color): AnnotatedString = buildAnnotatedString {
    var i = 0
    while (i < s.length) {
        val c = s[i]
        if (c == '`') {
            val e = s.indexOf('`', i + 1)
            if (e > i) {
                withStyle(SpanStyle(fontFamily = FontFamily.Monospace, background = codeBg)) {
                    append(s.substring(i + 1, e))
                }
                i = e + 1
                continue
            }
        }
        if (c == '*' && s.startsWith("**", i)) {
            val e = s.indexOf("**", i + 2)
            if (e > i + 2) {
                withStyle(SpanStyle(fontWeight = FontWeight.Bold)) {
                    append(inlineMd(s.substring(i + 2, e), codeBg, linkColor))
                }
                i = e + 2
                continue
            }
        }
        if (c == '*' && !s.startsWith("**", i) && i + 1 < s.length && !s[i + 1].isWhitespace()) {
            val e = s.indexOf('*', i + 1)
            if (e > i + 1 && !s[e - 1].isWhitespace()) {
                withStyle(SpanStyle(fontStyle = FontStyle.Italic)) {
                    append(inlineMd(s.substring(i + 1, e), codeBg, linkColor))
                }
                i = e + 1
                continue
            }
        }
        if (c == '_' && (i == 0 || !s[i - 1].isLetterOrDigit()) && i + 1 < s.length && !s[i + 1].isWhitespace() && s[i + 1] != '_') {
            val e = s.indexOf('_', i + 1)
            if (e > i + 1 && !s[e - 1].isWhitespace() && (e + 1 >= s.length || !s[e + 1].isLetterOrDigit())) {
                withStyle(SpanStyle(fontStyle = FontStyle.Italic)) {
                    append(inlineMd(s.substring(i + 1, e), codeBg, linkColor))
                }
                i = e + 1
                continue
            }
        }
        if (c == '[') {
            val m = RE_LINK.find(s, i)
            if (m != null && m.range.first == i) {
                withStyle(SpanStyle(color = linkColor, textDecoration = TextDecoration.Underline)) {
                    append(m.groupValues[1])
                }
                if (m.groupValues[1] != m.groupValues[2]) append(" (" + m.groupValues[2] + ")")
                i = m.range.last + 1
                continue
            }
        }
        append(c)
        i++
    }
}

@Composable
fun MarkdownText(text: String, modifier: Modifier = Modifier) {
    val blocks = remember(text) { parseBlocks(text) }
    val codeBg = MaterialTheme.colorScheme.surfaceContainerHighest
    val link = MaterialTheme.colorScheme.primary
    Column(modifier, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        blocks.forEach { b ->
            when (b) {
                is Block.Code -> CodeBlock(b)
                is Block.Heading -> Text(
                    inlineMd(b.text, codeBg, link),
                    style = when (b.level) {
                        1 -> MaterialTheme.typography.titleLarge
                        2 -> MaterialTheme.typography.titleMedium
                        else -> MaterialTheme.typography.titleSmall
                    },
                    fontWeight = FontWeight.Bold
                )
                is Block.Item -> Row(Modifier.padding(start = (b.indent * 16).dp)) {
                    Text(b.marker, modifier = Modifier.width(26.dp))
                    Text(inlineMd(b.text, codeBg, link), modifier = Modifier.weight(1f))
                }
                is Block.Quote -> Row(Modifier.height(IntrinsicSize.Min)) {
                    Box(
                        Modifier
                            .width(3.dp)
                            .fillMaxHeight()
                            .background(MaterialTheme.colorScheme.outline)
                    )
                    Text(
                        inlineMd(b.text, codeBg, link),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(start = 10.dp)
                    )
                }
                is Block.Para -> Text(inlineMd(b.text, codeBg, link))
                is Block.Rule -> HorizontalDivider()
            }
        }
    }
}

@Composable
fun CodeBlock(b: Block.Code) {
    val clip = LocalClipboardManager.current
    Surface(
        color = MaterialTheme.colorScheme.surfaceContainerHighest,
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column {
            Row(
                Modifier.fillMaxWidth().padding(start = 12.dp, end = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    b.lang.ifEmpty { "код" },
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.weight(1f)
                )
                TextButton(onClick = { clip.setText(AnnotatedString(b.code)) }) { Text("Копировать") }
            }
            Text(
                b.code,
                fontFamily = FontFamily.Monospace,
                fontSize = 13.sp,
                softWrap = false,
                modifier = Modifier
                    .horizontalScroll(rememberScrollState())
                    .padding(start = 12.dp, end = 12.dp, bottom = 12.dp)
            )
        }
    }
}
