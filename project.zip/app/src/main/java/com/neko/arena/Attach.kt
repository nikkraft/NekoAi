package com.neko.arena

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.provider.OpenableColumns
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.UUID
import kotlin.math.max

object Attach {
    private const val MAX_TEXT = 200_000
    private val TEXT_EXT = setOf(
        "txt", "md", "json", "csv", "tsv", "xml", "html", "htm", "css", "js", "ts", "kt", "kts",
        "java", "py", "c", "cpp", "h", "cs", "go", "rs", "rb", "php", "sh", "yml", "yaml", "toml",
        "ini", "log", "sql", "gradle", "swift", "tex", "properties"
    )

    sealed class Res {
        data class Img(val name: String) : Res()
        data class Txt(val file: FileAtt) : Res()
        data class Err(val msg: String) : Res()
    }

    private fun dir(ctx: Context): File = File(ctx.filesDir, "img").apply { mkdirs() }
    fun file(ctx: Context, name: String): File = File(dir(ctx), name)

    fun delete(ctx: Context, name: String) {
        try {
            file(ctx, name).delete()
        } catch (e: Exception) {
        }
    }

    fun process(ctx: Context, uri: Uri): Res {
        val cr = ctx.contentResolver
        val name = queryName(ctx, uri) ?: "file"
        val mime = cr.getType(uri).orEmpty()
        val ext = name.substringAfterLast('.', "").lowercase()
        return try {
            when {
                mime.startsWith("image/") -> image(ctx, uri, name)
                mime.startsWith("text/") || ext in TEXT_EXT ||
                    mime == "application/json" || mime == "application/xml" -> text(ctx, uri, name)
                else -> Res.Err("Формат не поддерживается: $name (можно изображения и текстовые файлы)")
            }
        } catch (e: Exception) {
            Res.Err("Не удалось прочитать $name")
        }
    }

    private fun queryName(ctx: Context, uri: Uri): String? = try {
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { if (it.moveToFirst()) it.getString(0) else null }
    } catch (e: Exception) {
        null
    }

    private fun text(ctx: Context, uri: Uri, name: String): Res {
        val bos = ByteArrayOutputStream()
        var truncated = false
        ctx.contentResolver.openInputStream(uri)?.use { input ->
            val buf = ByteArray(8192)
            var total = 0
            while (true) {
                val n = input.read(buf, 0, minOf(buf.size, MAX_TEXT - total))
                if (n <= 0) {
                    truncated = total >= MAX_TEXT && input.read() != -1
                    break
                }
                bos.write(buf, 0, n)
                total += n
            }
        } ?: return Res.Err("Не удалось открыть $name")
        val bytes = bos.toByteArray()
        if (bytes.any { it.toInt() == 0 }) return Res.Err("Файл $name не текстовый")
        var s = String(bytes, Charsets.UTF_8)
        if (truncated) s += "\n…[файл обрезан]"
        return Res.Txt(FileAtt(name, s))
    }

    private fun image(ctx: Context, uri: Uri, name: String): Res {
        val cr = ctx.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0) return Res.Err("Не удалось открыть $name")
        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / sample > 2560) sample *= 2
        val src = cr.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
        } ?: return Res.Err("Не удалось открыть $name")
        val orient = try {
            cr.openInputStream(uri)?.use {
                ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
            } ?: ExifInterface.ORIENTATION_NORMAL
        } catch (e: Exception) {
            ExifInterface.ORIENTATION_NORMAL
        }
        val deg = when (orient) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90f
            ExifInterface.ORIENTATION_ROTATE_180 -> 180f
            ExifInterface.ORIENTATION_ROTATE_270 -> 270f
            else -> 0f
        }
        val scale = (1280f / max(src.width, src.height)).coerceAtMost(1f)
        val m = Matrix().apply {
            postRotate(deg)
            postScale(scale, scale)
        }
        val rot = Bitmap.createBitmap(src, 0, 0, src.width, src.height, m, true)
        val flat = Bitmap.createBitmap(rot.width, rot.height, Bitmap.Config.ARGB_8888)
        Canvas(flat).apply {
            drawColor(Color.WHITE)
            drawBitmap(rot, 0f, 0f, null)
        }
        val fn = UUID.randomUUID().toString() + ".jpg"
        file(ctx, fn).outputStream().use { flat.compress(Bitmap.CompressFormat.JPEG, 82, it) }
        return Res.Img(fn)
    }

    fun thumb(ctx: Context, name: String, maxPx: Int): Bitmap? = try {
        val f = file(ctx, name)
        val b = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, b)
        var s = 1
        while (max(b.outWidth, b.outHeight) / s > maxPx * 2) s *= 2
        BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s })
    } catch (e: Exception) {
        null
    }
}
