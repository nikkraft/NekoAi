package com.neko.arena

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class Msg(val role: String, val content: String)
data class Chat(val id: String, val title: String, val messages: List<Msg>, val updated: Long)

class Store(private val ctx: Context) {
    companion object {
        const val DEFAULT_BASE = "https://api.preview.arena.ai/v1"
    }

    private val prefs = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)
    private val file get() = File(ctx.filesDir, "chats.json")

    var apiKey: String
        get() = prefs.getString("key", "") ?: ""
        set(v) = prefs.edit().putString("key", v.trim()).apply()

    var baseUrl: String
        get() = prefs.getString("base", DEFAULT_BASE) ?: DEFAULT_BASE
        set(v) = prefs.edit().putString("base", v.trim().trimEnd('/').ifEmpty { DEFAULT_BASE }).apply()

    var model: String
        get() = prefs.getString("model", "auto") ?: "auto"
        set(v) = prefs.edit().putString("model", v.trim().ifEmpty { "auto" }).apply()

    fun loadChats(): List<Chat> = try {
        val arr = JSONArray(file.readText())
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val ms = o.getJSONArray("m")
            Chat(
                o.getString("id"),
                o.getString("t"),
                (0 until ms.length()).map { k ->
                    val m = ms.getJSONObject(k)
                    Msg(m.getString("r"), m.getString("c"))
                },
                o.getLong("u")
            )
        }
    } catch (e: Exception) {
        emptyList()
    }

    fun saveChats(chats: List<Chat>) {
        val arr = JSONArray()
        chats.forEach { c ->
            val ms = JSONArray()
            c.messages.forEach { ms.put(JSONObject().put("r", it.role).put("c", it.content)) }
            arr.put(JSONObject().put("id", c.id).put("t", c.title).put("u", c.updated).put("m", ms))
        }
        try {
            file.writeText(arr.toString())
        } catch (e: Exception) {
        }
    }
}
