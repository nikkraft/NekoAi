package com.neko.arena

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

data class FileAtt(val name: String, val text: String)
data class Msg(
    val role: String,
    val content: String,
    val images: List<String> = emptyList(),
    val files: List<FileAtt> = emptyList()
)
data class Chat(val id: String, val title: String, val messages: List<Msg>, val updated: Long)

data class Provider(
    val id: String,
    val name: String,
    val type: String,      // Store.OPENAI или Store.ANTHROPIC
    val base: String,
    val key: String,
    val model: String,
    val headers: String    // доп. заголовки, по одному в строке: Имя: значение
)

data class Preset(val name: String, val type: String, val base: String)

class Store(private val ctx: Context) {
    companion object {
        const val OPENAI = "openai"
        const val ANTHROPIC = "anthropic"

        val PRESETS = listOf(
            Preset("OpenAI", OPENAI, "https://api.openai.com/v1"),
            Preset("Anthropic", ANTHROPIC, "https://api.anthropic.com/v1"),
            Preset("Google Gemini", OPENAI, "https://generativelanguage.googleapis.com/v1beta/openai"),
            Preset("OpenRouter", OPENAI, "https://openrouter.ai/api/v1"),
            Preset("Groq", OPENAI, "https://api.groq.com/openai/v1"),
            Preset("DeepSeek", OPENAI, "https://api.deepseek.com"),
            Preset("Mistral", OPENAI, "https://api.mistral.ai/v1"),
            Preset("xAI", OPENAI, "https://api.x.ai/v1"),
            Preset("Together AI", OPENAI, "https://api.together.xyz/v1"),
            Preset("Perplexity", OPENAI, "https://api.perplexity.ai"),
            Preset("Cerebras", OPENAI, "https://api.cerebras.ai/v1"),
            Preset("Fireworks", OPENAI, "https://api.fireworks.ai/inference/v1"),
            Preset("Arena", OPENAI, "https://api.preview.arena.ai/v1"),
            Preset("Ollama (свой сервер)", OPENAI, "http://192.168.0.2:11434/v1"),
            Preset("LM Studio (свой сервер)", OPENAI, "http://192.168.0.2:1234/v1")
        )
    }

    private val prefs = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)
    private val file get() = File(ctx.filesDir, "chats.json")

    var system: String
        get() = prefs.getString("sys", "") ?: ""
        set(v) = prefs.edit().putString("sys", v.trim()).apply()

    var activeId: String
        get() = prefs.getString("active", "") ?: ""
        set(v) = prefs.edit().putString("active", v).apply()

    // ---------- провайдеры ----------

    fun loadProviders(): List<Provider> {
        val raw = prefs.getString("providers", null)
        if (raw == null) {
            // миграция со старой версии (один ключ Arena)
            val oldKey = prefs.getString("key", "") ?: ""
            if (oldKey.isNotBlank()) {
                val p = Provider(
                    UUID.randomUUID().toString(), "Arena", OPENAI,
                    prefs.getString("base", "https://api.preview.arena.ai/v1") ?: "https://api.preview.arena.ai/v1",
                    oldKey, prefs.getString("model", "auto") ?: "auto", ""
                )
                saveProviders(listOf(p))
                activeId = p.id
                return listOf(p)
            }
            return emptyList()
        }
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Provider(
                    o.getString("id"), o.getString("n"), o.optString("t", OPENAI), o.getString("b"),
                    o.optString("k", ""), o.optString("m", ""), o.optString("h", "")
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun saveProviders(list: List<Provider>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject().put("id", it.id).put("n", it.name).put("t", it.type).put("b", it.base)
                    .put("k", it.key).put("m", it.model).put("h", it.headers)
            )
        }
        prefs.edit().putString("providers", arr.toString()).apply()
    }

    // ---------- чаты ----------

    fun loadChats(): List<Chat> = try {
        val arr = JSONArray(file.readText())
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val ms = o.getJSONArray("m")
            Chat(
                o.getString("id"),
                o.getString("t"),
                (0 until ms.length()).map { k ->
                    val m = ms.getJSONObject(k)
                    val im = m.optJSONArray("i")
                    val fl = m.optJSONArray("f")
                    Msg(
                        m.getString("r"),
                        m.getString("c"),
                        if (im == null) emptyList() else (0 until im.length()).map { im.getString(it) },
                        if (fl == null) emptyList() else (0 until fl.length()).map {
                            val f = fl.getJSONObject(it)
                            FileAtt(f.getString("n"), f.getString("t"))
                        }
                    )
                },
                o.getLong("u")
            )
        }
    } catch (e: Exception) {
        emptyList()
    }

    fun saveChats(chats: List<Chat>) {
        val arr = JSONArray()
        chats.forEach { c ->
            val ms = JSONArray()
            c.messages.forEach { m ->
                val o = JSONObject().put("r", m.role).put("c", m.content)
                if (m.images.isNotEmpty()) o.put("i", JSONArray(m.images))
                if (m.files.isNotEmpty()) {
                    val fa = JSONArray()
                    m.files.forEach { fa.put(JSONObject().put("n", it.name).put("t", it.text)) }
                    o.put("f", fa)
                }
                ms.put(o)
            }
            arr.put(JSONObject().put("id", c.id).put("t", c.title).put("u", c.updated).put("m", ms))
        }
        try {
            file.writeText(arr.toString())
        } catch (e: Exception) {
        }
    }
}
