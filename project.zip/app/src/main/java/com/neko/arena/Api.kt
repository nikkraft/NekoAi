package com.neko.arena

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

object Api {
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(90, TimeUnit.SECONDS)
        .readTimeout(180, TimeUnit.SECONDS)
        .build()
    private val JSON = "application/json; charset=utf-8".toMediaType()

    private fun request(p: Provider, path: String): Request.Builder {
        val rb = try {
            Request.Builder().url(p.base.trim().trimEnd('/') + path)
        } catch (e: IllegalArgumentException) {
            throw IOException("Неверный адрес API: ${p.base}")
        }
        if (p.type == Store.ANTHROPIC) {
            if (p.key.isNotBlank()) rb.header("x-api-key", p.key)
            rb.header("anthropic-version", "2023-06-01")
        } else if (p.key.isNotBlank()) {
            rb.header("Authorization", "Bearer ${p.key}")
        }
        p.headers.lineSequence().forEach { line ->
            val i = line.indexOf(':')
            if (i > 0) {
                val k = line.substring(0, i).trim()
                val v = line.substring(i + 1).trim()
                if (k.isNotEmpty()) {
                    try {
                        rb.header(k, v)
                    } catch (e: IllegalArgumentException) {
                    }
                }
            }
        }
        return rb
    }

    private fun withFiles(m: Msg): String =
        m.content + m.files.joinToString("") { "\n\n[Файл: ${it.name}]\n```\n${it.text}\n```" }

    private fun openAiMessages(system: String, history: List<Msg>, img: (String) -> String?): JSONArray {
        val arr = JSONArray()
        if (system.isNotBlank()) arr.put(JSONObject().put("role", "system").put("content", system))
        history.forEach { m ->
            val text = withFiles(m)
            val pics = m.images.mapNotNull { img(it) }
            if (pics.isEmpty()) {
                arr.put(JSONObject().put("role", m.role).put("content", text))
            } else {
                val parts = JSONArray()
                if (text.isNotBlank()) parts.put(JSONObject().put("type", "text").put("text", text))
                pics.forEach {
                    parts.put(
                        JSONObject().put("type", "image_url")
                            .put("image_url", JSONObject().put("url", "data:image/jpeg;base64,$it"))
                    )
                }
                arr.put(JSONObject().put("role", m.role).put("content", parts))
            }
        }
        return arr
    }

    private fun anthropicMessages(history: List<Msg>, img: (String) -> String?): JSONArray {
        val arr = JSONArray()
        history.forEach { m ->
            val text = withFiles(m)
            val parts = JSONArray()
            m.images.mapNotNull { img(it) }.forEach {
                parts.put(
                    JSONObject().put("type", "image").put(
                        "source",
                        JSONObject().put("type", "base64").put("media_type", "image/jpeg").put("data", it)
                    )
                )
            }
            if (text.isNotBlank()) parts.put(JSONObject().put("type", "text").put("text", text))
            if (parts.length() > 0) arr.put(JSONObject().put("role", m.role).put("content", parts))
        }
        return arr
    }

    fun stream(
        p: Provider,
        model: String,
        system: String,
        history: List<Msg>,
        img: (String) -> String?
    ): Flow<String> = flow {
        val anth = p.type == Store.ANTHROPIC
        val payload = JSONObject().put("model", model).put("stream", true)
        if (anth) {
            payload.put("max_tokens", 4096).put("messages", anthropicMessages(history, img))
            if (system.isNotBlank()) payload.put("system", system)
        } else {
            payload.put("messages", openAiMessages(system, history, img))
        }
        val req = request(p, if (anth) "/messages" else "/chat/completions")
            .post(payload.toString().toRequestBody(JSON))
            .build()
        val call = client.newCall(req)
        val reg = currentCoroutineContext()[Job]?.invokeOnCompletion { if (it != null) call.cancel() }
        try {
            call.execute().use { resp ->
                if (!resp.isSuccessful) throw IOException(errorText(resp.code, resp.body?.string()))
                val body = resp.body ?: throw IOException("Пустой ответ сервера")
                val type = resp.header("Content-Type").orEmpty()
                if (type.contains("event-stream")) {
                    val src = body.source()
                    while (true) {
                        val line = src.readUtf8Line() ?: break
                        if (!line.startsWith("data:")) continue
                        val data = line.substring(5).trim()
                        if (data.isEmpty()) continue
                        if (data == "[DONE]") break
                        val delta = if (anth) parseAnthropic(data) else parseOpenAi(data)
                        if (delta.isNotEmpty()) emit(delta)
                    }
                } else {
                    val text = parseFull(body.string(), anth)
                    if (text.isNotEmpty()) emit(text)
                }
            }
        } finally {
            reg?.dispose()
        }
    }.flowOn(Dispatchers.IO)

    suspend fun models(p: Provider): List<String> = withContext(Dispatchers.IO) {
        val path = if (p.type == Store.ANTHROPIC) "/models?limit=100" else "/models"
        val req = request(p, path).build()
        client.newCall(req).execute().use { resp ->
            val text = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) throw IOException(errorText(resp.code, text))
            val data = try {
                JSONObject(text).optJSONArray("data") ?: JSONArray()
            } catch (e: Exception) {
                throw IOException("Сервер не отдаёт список моделей, введи название вручную")
            }
            (0 until data.length())
                .mapNotNull { data.optJSONObject(it)?.optString("id")?.takeIf { s -> s.isNotEmpty() } }
                .map { it.removePrefix("models/") }
                .sorted()
        }
    }

    private fun parseOpenAi(data: String): String {
        val j = try {
            JSONObject(data)
        } catch (e: Exception) {
            return ""
        }
        if (j.has("error")) throw IOException(errMsg(j.opt("error")))
        val d = j.optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("delta") ?: return ""
        return if (d.isNull("content")) "" else d.optString("content")
    }

    private fun parseAnthropic(data: String): String {
        val j = try {
            JSONObject(data)
        } catch (e: Exception) {
            return ""
        }
        when (j.optString("type")) {
            "error" -> throw IOException(errMsg(j.opt("error")))
            "content_block_delta" -> {
                val d = j.optJSONObject("delta")
                if (d != null && d.optString("type") == "text_delta") return d.optString("text")
            }
        }
        return ""
    }

    private fun parseFull(text: String, anth: Boolean): String {
        val j = try {
            JSONObject(text)
        } catch (e: Exception) {
            throw IOException("Неожиданный ответ сервера")
        }
        if (j.has("error")) throw IOException(errMsg(j.opt("error")))
        if (anth) {
            val c = j.optJSONArray("content") ?: return ""
            val sb = StringBuilder()
            for (i in 0 until c.length()) {
                val b = c.optJSONObject(i) ?: continue
                if (b.optString("type") == "text") sb.append(b.optString("text"))
            }
            return sb.toString()
        }
        val m = j.optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message") ?: return ""
        return if (m.isNull("content")) "" else m.optString("content")
    }

    private fun errMsg(e: Any?): String =
        if (e is JSONObject) e.optString("message", "Ошибка API") else e?.toString() ?: "Ошибка API"

    private fun errorText(code: Int, body: String?): String {
        val msg = try {
            val j = JSONObject(body ?: "")
            j.optJSONObject("error")?.optString("message") ?: j.optString("message")
        } catch (e: Exception) {
            null
        }
        val hint = when (code) {
            401, 403 -> "неверный ключ или нет доступа"
            404 -> "неверный адрес или модель"
            429 -> "превышен лимит запросов"
            else -> ""
        }
        return listOf("HTTP $code", hint, msg.orEmpty().take(300))
            .filter { it.isNotEmpty() }
            .joinToString(": ")
    }
}
