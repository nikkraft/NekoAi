package com.neko.arena

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

object Api {
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(180, TimeUnit.SECONDS)
        .build()
    private val JSON = "application/json; charset=utf-8".toMediaType()

    fun stream(base: String, key: String, model: String, msgs: List<Msg>): Flow<String> = flow {
        val arr = JSONArray()
        msgs.forEach { arr.put(JSONObject().put("role", it.role).put("content", it.content)) }
        val payload = JSONObject()
            .put("model", model)
            .put("stream", true)
            .put("messages", arr)
            .toString()
        val req = Request.Builder()
            .url("$base/chat/completions")
            .header("Authorization", "Bearer $key")
            .post(payload.toRequestBody(JSON))
            .build()
        val call = client.newCall(req)
        val reg = currentCoroutineContext()[Job]?.invokeOnCompletion { if (it != null) call.cancel() }
        try {
            call.execute().use { resp ->
                if (!resp.isSuccessful) throw IOException(errorText(resp.code, resp.body?.string()))
                val body = resp.body ?: throw IOException("Пустой ответ сервера")
                val type = resp.header("Content-Type").orEmpty()
                if (type.contains("event-stream")) {
                    val src = body.source()
                    while (true) {
                        val line = src.readUtf8Line() ?: break
                        if (!line.startsWith("data:")) continue
                        val data = line.substring(5).trim()
                        if (data.isEmpty()) continue
                        if (data == "[DONE]") break
                        val delta = parseDelta(data)
                        if (delta.isNotEmpty()) emit(delta)
                    }
                } else {
                    val text = parseFull(body.string())
                    if (text.isNotEmpty()) emit(text)
                }
            }
        } finally {
            reg?.dispose()
        }
    }.flowOn(Dispatchers.IO)

    suspend fun models(base: String, key: String): List<String> = withContext(Dispatchers.IO) {
        val req = Request.Builder()
            .url("$base/models")
            .header("Authorization", "Bearer $key")
            .build()
        client.newCall(req).execute().use { resp ->
            val text = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) throw IOException(errorText(resp.code, text))
            val data = JSONObject(text).optJSONArray("data") ?: JSONArray()
            (0 until data.length())
                .mapNotNull { data.optJSONObject(it)?.optString("id")?.takeIf { s -> s.isNotEmpty() } }
                .sorted()
        }
    }

    private fun parseDelta(data: String): String {
        val j = try {
            JSONObject(data)
        } catch (e: Exception) {
            return ""
        }
        if (j.has("error")) throw IOException(errMsg(j.opt("error")))
        val d = j.optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("delta") ?: return ""
        return if (d.isNull("content")) "" else d.optString("content")
    }

    private fun parseFull(text: String): String {
        val j = try {
            JSONObject(text)
        } catch (e: Exception) {
            throw IOException("Неожиданный ответ сервера")
        }
        if (j.has("error")) throw IOException(errMsg(j.opt("error")))
        val m = j.optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message") ?: return ""
        return if (m.isNull("content")) "" else m.optString("content")
    }

    private fun errMsg(e: Any?): String =
        if (e is JSONObject) e.optString("message", "Ошибка API") else e?.toString() ?: "Ошибка API"

    private fun errorText(code: Int, body: String?): String {
        val msg = try {
            val j = JSONObject(body ?: "")
            j.optJSONObject("error")?.optString("message") ?: j.optString("message")
        } catch (e: Exception) {
            null
        }
        val hint = when (code) {
            401, 403 -> "неверный ключ или нет доступа"
            429 -> "превышен лимит запросов"
            else -> ""
        }
        return listOf("HTTP $code", hint, msg.orEmpty().take(300))
            .filter { it.isNotEmpty() }
            .joinToString(": ")
    }
}
