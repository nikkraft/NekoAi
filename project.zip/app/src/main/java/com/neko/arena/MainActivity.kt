package com.neko.arena

import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContent { NekoArenaTheme { App() } }
    }
}

@Composable
fun NekoArenaTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val ctx = LocalContext.current
    val scheme = when {
        Build.VERSION.SDK_INT >= 31 -> if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> darkColorScheme()
        else -> lightColorScheme()
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

// ===================== Приложение + боковое меню =====================

@Composable
fun App(vm: ChatVM = viewModel()) {
    val drawer = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    var settings by remember { mutableStateOf(false) }
    var showModel by remember { mutableStateOf(false) }
    var showProviders by remember { mutableStateOf(false) }
    var presetPicker by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Provider?>(null) }
    var query by remember { mutableStateOf("") }
    var menuId by remember { mutableStateOf<String?>(null) }
    var renaming by remember { mutableStateOf<Chat?>(null) }

    val shown = vm.chats.filter { c ->
        query.isBlank() || c.title.contains(query, true) || c.messages.any { it.content.contains(query, true) }
    }

    ModalNavigationDrawer(
        drawerState = drawer,
        drawerContent = {
            ModalDrawerSheet {
                Text(
                    "NekoArena",
                    style = MaterialTheme.typography.titleLarge,
                    modifier = Modifier.padding(horizontal = 28.dp, vertical = 20.dp)
                )
                NavigationDrawerItem(
                    label = { Text("Новый чат") },
                    icon = { Icon(Icons.Default.Add, null) },
                    selected = false,
                    onClick = { vm.newChat(); scope.launch { drawer.close() } },
                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                )
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = { Text("Поиск по чатам") },
                    leadingIcon = { Icon(Icons.Default.Search, null) },
                    singleLine = true,
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)
                )
                HorizontalDivider(Modifier.padding(vertical = 8.dp))
                LazyColumn(Modifier.weight(1f)) {
                    items(shown, key = { it.id }) { c ->
                        NavigationDrawerItem(
                            label = { Text(c.title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                            selected = c.id == vm.currentId,
                            onClick = { vm.open(c.id); scope.launch { drawer.close() } },
                            badge = {
                                Box {
                                    IconButton(onClick = { menuId = c.id }) {
                                        Icon(Icons.Default.MoreVert, "Меню чата")
                                    }
                                    DropdownMenu(expanded = menuId == c.id, onDismissRequest = { menuId = null }) {
                                        DropdownMenuItem(
                                            text = { Text("Переименовать") },
                                            onClick = { renaming = c; menuId = null }
                                        )
                                        DropdownMenuItem(
                                            text = { Text("Удалить") },
                                            onClick = { vm.delete(c.id); menuId = null }
                                        )
                                    }
                                }
                            },
                            modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                        )
                    }
                }
                NavigationDrawerItem(
                    label = { Text("Провайдеры") },
                    icon = { Icon(Icons.Default.Build, null) },
                    selected = false,
                    onClick = { showProviders = true; scope.launch { drawer.close() } },
                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                )
                NavigationDrawerItem(
                    label = { Text("Настройки") },
                    icon = { Icon(Icons.Default.Settings, null) },
                    selected = false,
                    onClick = { settings = true; scope.launch { drawer.close() } },
                    modifier = Modifier
                        .padding(NavigationDrawerItemDefaults.ItemPadding)
                        .navigationBarsPadding()
                )
            }
        }
    ) {
        ChatScreen(
            vm,
            onMenu = { scope.launch { drawer.open() } },
            onModel = { if (vm.providers.isEmpty()) showProviders = true else showModel = true },
            onProviders = { showProviders = true }
        )
    }

    if (settings) SettingsDialog(vm) { settings = false }
    if (showModel) ModelDialog(vm) { showModel = false }
    if (showProviders) {
        ProvidersDialog(
            vm,
            onClose = { showProviders = false },
            onAdd = { presetPicker = true },
            onEdit = { editing = it }
        )
    }
    if (presetPicker) {
        PresetDialog(onClose = { presetPicker = false }) { pr ->
            presetPicker = false
            editing = Provider(
                UUID.randomUUID().toString(),
                if (pr.base.isEmpty()) "" else pr.name,
                pr.type, pr.base, "",
                if (pr.name == "Arena") "auto" else "",
                ""
            )
        }
    }
    editing?.let { d -> key(d.id) { EditProviderDialog(d, vm) { editing = null } } }

    renaming?.let { c ->
        var t by remember(c.id) { mutableStateOf(c.title) }
        AlertDialog(
            onDismissRequest = { renaming = null },
            title = { Text("Название чата") },
            text = { OutlinedTextField(t, { t = it }, singleLine = true, modifier = Modifier.fillMaxWidth()) },
            confirmButton = { TextButton(onClick = { vm.rename(c.id, t); renaming = null }) { Text("Сохранить") } },
            dismissButton = { TextButton(onClick = { renaming = null }) { Text("Отмена") } }
        )
    }
}

// ===================== Экран чата =====================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(vm: ChatVM, onMenu: () -> Unit, onModel: () -> Unit, onProviders: () -> Unit) {
    var input by remember { mutableStateOf("") }
    val msgs = vm.current?.messages ?: emptyList()
    val list = rememberLazyListState()
    val clip = LocalClipboardManager.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        vm.addAttachments(uris)
    }
    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty()) list.scrollToItem(0) }

    Scaffold(
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        topBar = {
            TopAppBar(
                title = { Text(vm.current?.title ?: "NekoArena", maxLines = 1, overflow = TextOverflow.Ellipsis) },
                navigationIcon = { IconButton(onClick = onMenu) { Icon(Icons.Default.Menu, "Меню") } },
                actions = {
                    TextButton(onClick = onModel) {
                        Text(
                            vm.active?.let { it.name + " · " + it.model.ifBlank { "?" } } ?: "Провайдер",
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.widthIn(max = 170.dp)
                        )
                    }
                }
            )
        }
    ) { pad ->
        Column(
            Modifier
                .padding(pad)
                .fillMaxSize()
                .navigationBarsPadding()
                .imePadding()
        ) {
            Box(Modifier.weight(1f).fillMaxWidth()) {
                if (msgs.isEmpty()) {
                    EmptyState(vm, onProviders)
                } else {
                    LazyColumn(
                        state = list,
                        reverseLayout = true,
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(12.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(msgs.size) { i ->
                            val idx = msgs.lastIndex - i
                            val m = msgs[idx]
                            val last = idx == msgs.lastIndex
                            if (m.role == "user") {
                                UserMessage(
                                    m, showActions = last && !vm.streaming,
                                    onRetry = { vm.regenerate() },
                                    onEdit = { vm.editLast()?.let { input = it } }
                                )
                            } else {
                                AssistantMessage(
                                    m, working = last && vm.streaming, showActions = last && !vm.streaming,
                                    onCopy = { clip.setText(AnnotatedString(m.content)) },
                                    onRetry = { vm.regenerate() },
                                    onEdit = { vm.editLast()?.let { input = it } }
                                )
                            }
                        }
                    }
                }
            }
            vm.error?.let {
                Text(
                    it,
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { vm.error = null }
                        .padding(horizontal = 16.dp, vertical = 4.dp)
                )
            }
            if (vm.pendingImages.isNotEmpty() || vm.pendingFiles.isNotEmpty()) {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    items(vm.pendingImages) { fn ->
                        Box(Modifier.size(64.dp)) {
                            Thumb(fn, 64.dp)
                            Box(
                                Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(2.dp)
                                    .size(20.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.scrim.copy(alpha = 0.6f))
                                    .clickable { vm.removePendingImage(fn) },
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Close, "Убрать", tint = Color.White, modifier = Modifier.size(14.dp))
                            }
                        }
                    }
                    items(vm.pendingFiles) { f ->
                        InputChip(
                            selected = false,
                            onClick = { vm.removePendingFile(f) },
                            label = { Text(f.name, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 160.dp)) },
                            trailingIcon = { Icon(Icons.Default.Close, "Убрать", Modifier.size(16.dp)) }
                        )
                    }
                }
            }
            Row(
                Modifier.fillMaxWidth().padding(8.dp),
                verticalAlignment = Alignment.Bottom
            ) {
                IconButton(onClick = { picker.launch("*/*") }, modifier = Modifier.size(56.dp)) {
                    Icon(Icons.Default.Add, "Прикрепить")
                }
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Сообщение") },
                    maxLines = 6,
                    shape = RoundedCornerShape(24.dp)
                )
                Spacer(Modifier.width(8.dp))
                FilledIconButton(
                    onClick = {
                        if (vm.streaming) vm.stop()
                        else if (vm.send(input)) input = ""
                    },
                    enabled = vm.streaming || input.isNotBlank() ||
                        vm.pendingImages.isNotEmpty() || vm.pendingFiles.isNotEmpty(),
                    modifier = Modifier.size(56.dp)
                ) {
                    if (vm.streaming) Icon(Icons.Default.Close, "Стоп")
                    else Icon(Icons.AutoMirrored.Filled.Send, "Отправить")
                }
            }
        }
    }
}

@Composable
fun EmptyState(vm: ChatVM, onProviders: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Чем помочь?", style = MaterialTheme.typography.headlineSmall)
        if (vm.active == null) {
            Spacer(Modifier.height(16.dp))
            Text(
                "Добавь провайдера: OpenAI, Anthropic, Gemini, OpenRouter или свой сервер",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(12.dp))
            FilledTonalButton(onClick = onProviders) { Text("Добавить провайдера") }
        }
    }
}

// ===================== Сообщения =====================

@Composable
fun UserMessage(m: Msg, showActions: Boolean, onRetry: () -> Unit, onEdit: () -> Unit) {
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.End) {
        Surface(
            color = MaterialTheme.colorScheme.primaryContainer,
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier.widthIn(max = 320.dp)
        ) {
            Column(
                Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                if (m.images.isNotEmpty()) {
                    Row(
                        Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) { m.images.forEach { Thumb(it, 96.dp) } }
                }
                m.files.forEach {
                    AssistChip(
                        onClick = {},
                        label = { Text(it.name, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                    )
                }
                if (m.content.isNotEmpty()) SelectionContainer { Text(m.content) }
            }
        }
        if (showActions) ActionsRow(false, {}, onRetry, onEdit)
    }
}

@Composable
fun AssistantMessage(
    m: Msg,
    working: Boolean,
    showActions: Boolean,
    onCopy: () -> Unit,
    onRetry: () -> Unit,
    onEdit: () -> Unit
) {
    Column(Modifier.fillMaxWidth()) {
        SelectionContainer {
            if (m.content.isEmpty()) Text(if (working) "…" else "")
            else MarkdownText(m.content)
        }
        if (showActions) ActionsRow(true, onCopy, onRetry, onEdit)
    }
}

@Composable
fun ActionsRow(copy: Boolean, onCopy: () -> Unit, onRetry: () -> Unit, onEdit: () -> Unit) {
    val pad = PaddingValues(horizontal = 10.dp)
    Row {
        if (copy) TextButton(onClick = onCopy, contentPadding = pad) { Text("Копировать") }
        TextButton(onClick = onRetry, contentPadding = pad) { Text("Повторить") }
        TextButton(onClick = onEdit, contentPadding = pad) { Text("Изменить") }
    }
}

@Composable
fun Thumb(file: String, size: Dp) {
    val ctx = LocalContext.current
    val bmp by produceState<ImageBitmap?>(null, file) {
        value = withContext(Dispatchers.IO) { Attach.thumb(ctx, file, 256) }?.asImageBitmap()
    }
    Box(
        Modifier
            .size(size)
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceContainerHigh)
    ) {
        bmp?.let { Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
    }
}

// ===================== Настройки и провайдеры =====================

@Composable
fun SettingsDialog(vm: ChatVM, onClose: () -> Unit) {
    var sys by remember { mutableStateOf(vm.system) }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Настройки") },
        text = {
            OutlinedTextField(
                sys, { sys = it },
                label = { Text("Системный промпт") },
                minLines = 3,
                maxLines = 8,
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = { TextButton(onClick = { vm.saveSystem(sys); onClose() }) { Text("Сохранить") } },
        dismissButton = { TextButton(onClick = onClose) { Text("Отмена") } }
    )
}

@Composable
fun ModelField(model: String, onModel: (String) -> Unit, vm: ChatVM, provider: () -> Provider) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(
            model, onModel,
            label = { Text("Модель") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        TextButton(onClick = { vm.loadModels(provider()) }, enabled = !vm.loadingModels) {
            Text(if (vm.loadingModels) "Загрузка…" else "Список моделей")
        }
        vm.modelsError?.let {
            Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        }
        val shown = vm.models.filter { model.isBlank() || it.contains(model, true) }.take(100)
        if (shown.isNotEmpty() && !(shown.size == 1 && shown[0] == model)) {
            Column(Modifier.heightIn(max = 180.dp).verticalScroll(rememberScrollState())) {
                shown.forEach { m ->
                    Text(
                        m,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onModel(m) }
                            .padding(vertical = 8.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun ModelDialog(vm: ChatVM, onClose: () -> Unit) {
    var pid by remember { mutableStateOf(vm.activeId) }
    val prov = vm.providers.find { it.id == pid }
    var model by remember(pid) { mutableStateOf(prov?.model ?: "") }
    LaunchedEffect(pid) { vm.clearModels() }

    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Модель") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(vm.providers) { p ->
                        FilterChip(selected = p.id == pid, onClick = { pid = p.id }, label = { Text(p.name) })
                    }
                }
                if (prov != null) ModelField(model, { model = it }, vm) { prov }
            }
        },
        confirmButton = {
            TextButton(
                enabled = prov != null && model.isNotBlank(),
                onClick = {
                    prov?.let { vm.setModel(it.id, model); vm.selectProvider(it.id) }
                    onClose()
                }
            ) { Text("Выбрать") }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("Отмена") } }
    )
}

@Composable
fun ProvidersDialog(vm: ChatVM, onClose: () -> Unit, onAdd: () -> Unit, onEdit: (Provider) -> Unit) {
    var toDelete by remember { mutableStateOf<Provider?>(null) }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Провайдеры") },
        text = {
            if (vm.providers.isEmpty()) {
                Text("Пока пусто. Нажми «Добавить».")
            } else {
                LazyColumn(Modifier.heightIn(max = 380.dp)) {
                    items(vm.providers, key = { it.id }) { p ->
                        Row(
                            Modifier.fillMaxWidth().clickable { vm.selectProvider(p.id) },
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(selected = p.id == vm.activeId, onClick = { vm.selectProvider(p.id) })
                            Column(Modifier.weight(1f)) {
                                Text(p.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(
                                    p.model.ifBlank { "модель не выбрана" },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            IconButton(onClick = { onEdit(p) }) { Icon(Icons.Default.Edit, "Изменить") }
                            IconButton(onClick = { toDelete = p }) { Icon(Icons.Default.Delete, "Удалить") }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onAdd) { Text("Добавить") } },
        dismissButton = { TextButton(onClick = onClose) { Text("Закрыть") } }
    )
    toDelete?.let { p ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("Удалить «" + p.name + "»?") },
            text = { Text("Ключ и настройки провайдера будут удалены.") },
            confirmButton = { TextButton(onClick = { vm.deleteProvider(p.id); toDelete = null }) { Text("Удалить") } },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Отмена") } }
        )
    }
}

@Composable
fun PresetDialog(onClose: () -> Unit, onPick: (Preset) -> Unit) {
    val list = Store.PRESETS + listOf(
        Preset("Свой (OpenAI API)", Store.OPENAI, ""),
        Preset("Свой (Anthropic API)", Store.ANTHROPIC, "")
    )
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Добавить провайдера") },
        text = {
            LazyColumn(Modifier.heightIn(max = 400.dp)) {
                items(list) { p ->
                    Text(
                        p.name,
                        style = MaterialTheme.typography.bodyLarge,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onPick(p) }
                            .padding(vertical = 12.dp)
                    )
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onClose) { Text("Отмена") } }
    )
}

@Composable
fun EditProviderDialog(draft: Provider, vm: ChatVM, onClose: () -> Unit) {
    var name by remember { mutableStateOf(draft.name) }
    var type by remember { mutableStateOf(draft.type) }
    var base by remember { mutableStateOf(draft.base) }
    var key by remember { mutableStateOf(draft.key) }
    var model by remember { mutableStateOf(draft.model) }
    var headers by remember { mutableStateOf(draft.headers) }
    LaunchedEffect(Unit) { vm.clearModels() }

    fun cur() = Provider(
        draft.id, name.trim(), type, base.trim().trimEnd('/'), key.trim(), model.trim(), headers.trim()
    )

    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Провайдер") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    name, { name = it },
                    label = { Text("Название") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = type == Store.OPENAI,
                        onClick = { type = Store.OPENAI },
                        label = { Text("OpenAI API") }
                    )
                    FilterChip(
                        selected = type == Store.ANTHROPIC,
                        onClick = { type = Store.ANTHROPIC },
                        label = { Text("Anthropic API") }
                    )
                }
                OutlinedTextField(
                    base, { base = it },
                    label = { Text("Адрес API") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    key, { key = it },
                    label = { Text("API-ключ (для локальных можно пусто)") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth()
                )
                ModelField(model, { model = it }, vm) { cur() }
                OutlinedTextField(
                    headers, { headers = it },
                    label = { Text("Доп. заголовки (Имя: значение)") },
                    minLines = 2,
                    maxLines = 4,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            TextButton(
                enabled = name.isNotBlank() && base.isNotBlank(),
                onClick = { vm.saveProvider(cur()); onClose() }
            ) { Text("Сохранить") }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("Отмена") } }
    )
}
