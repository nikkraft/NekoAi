package com.neko.arena

import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContent { NekoArenaTheme { App() } }
    }
}

@Composable
fun NekoArenaTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val ctx = LocalContext.current
    val scheme = when {
        Build.VERSION.SDK_INT >= 31 -> if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> darkColorScheme()
        else -> lightColorScheme()
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

@Composable
fun App(vm: ChatVM = viewModel()) {
    val drawer = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    var settings by remember { mutableStateOf(false) }

    ModalNavigationDrawer(
        drawerState = drawer,
        drawerContent = {
            ModalDrawerSheet {
                Text(
                    "NekoArena",
                    style = MaterialTheme.typography.titleLarge,
                    modifier = Modifier.padding(horizontal = 28.dp, vertical = 20.dp)
                )
                NavigationDrawerItem(
                    label = { Text("Новый чат") },
                    icon = { Icon(Icons.Default.Add, null) },
                    selected = false,
                    onClick = { vm.newChat(); scope.launch { drawer.close() } },
                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                )
                HorizontalDivider(Modifier.padding(vertical = 8.dp))
                LazyColumn(Modifier.weight(1f)) {
                    items(vm.chats, key = { it.id }) { c ->
                        NavigationDrawerItem(
                            label = { Text(c.title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                            selected = c.id == vm.currentId,
                            onClick = { vm.open(c.id); scope.launch { drawer.close() } },
                            badge = {
                                IconButton(onClick = { vm.delete(c.id) }) {
                                    Icon(Icons.Default.Delete, "Удалить")
                                }
                            },
                            modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                        )
                    }
                }
                NavigationDrawerItem(
                    label = { Text("Настройки") },
                    icon = { Icon(Icons.Default.Settings, null) },
                    selected = false,
                    onClick = { settings = true; scope.launch { drawer.close() } },
                    modifier = Modifier
                        .padding(NavigationDrawerItemDefaults.ItemPadding)
                        .navigationBarsPadding()
                )
            }
        }
    ) {
        ChatScreen(vm, onMenu = { scope.launch { drawer.open() } }, onSettings = { settings = true })
    }

    if (settings) SettingsDialog(vm) { settings = false }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(vm: ChatVM, onMenu: () -> Unit, onSettings: () -> Unit) {
    var input by remember { mutableStateOf("") }
    val msgs = vm.current?.messages ?: emptyList()
    val list = rememberLazyListState()
    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty()) list.scrollToItem(0) }

    Scaffold(
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        topBar = {
            TopAppBar(
                title = { Text(vm.current?.title ?: "NekoArena", maxLines = 1, overflow = TextOverflow.Ellipsis) },
                navigationIcon = { IconButton(onClick = onMenu) { Icon(Icons.Default.Menu, "Меню") } },
                actions = { TextButton(onClick = onSettings) { Text(vm.model) } }
            )
        }
    ) { pad ->
        Column(
            Modifier
                .padding(pad)
                .fillMaxSize()
                .navigationBarsPadding()
                .imePadding()
        ) {
            Box(Modifier.weight(1f).fillMaxWidth()) {
                if (msgs.isEmpty()) {
                    EmptyState(vm, onSettings)
                } else {
                    LazyColumn(
                        state = list,
                        reverseLayout = true,
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(msgs.size) { i ->
                            val idx = msgs.lastIndex - i
                            Bubble(msgs[idx], vm.streaming && idx == msgs.lastIndex)
                        }
                    }
                }
            }
            vm.error?.let {
                Text(
                    it,
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { vm.error = null }
                        .padding(horizontal = 16.dp, vertical = 4.dp)
                )
            }
            Row(
                Modifier.fillMaxWidth().padding(8.dp),
                verticalAlignment = Alignment.Bottom
            ) {
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Сообщение") },
                    maxLines = 6,
                    shape = RoundedCornerShape(24.dp)
                )
                Spacer(Modifier.width(8.dp))
                FilledIconButton(
                    onClick = {
                        if (vm.streaming) vm.stop()
                        else if (vm.send(input)) input = ""
                    },
                    enabled = vm.streaming || input.isNotBlank(),
                    modifier = Modifier.size(56.dp)
                ) {
                    if (vm.streaming) Icon(Icons.Default.Close, "Стоп")
                    else Icon(Icons.AutoMirrored.Filled.Send, "Отправить")
                }
            }
        }
    }
}

@Composable
fun EmptyState(vm: ChatVM, onSettings: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Чем помочь?", style = MaterialTheme.typography.headlineSmall)
        if (vm.apiKey.isBlank()) {
            Spacer(Modifier.height(16.dp))
            Text(
                "Нужен API-ключ Arena",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(12.dp))
            FilledTonalButton(onClick = onSettings) { Text("Открыть настройки") }
        }
    }
}

@Composable
fun Bubble(m: Msg, pending: Boolean) {
    val user = m.role == "user"
    Box(
        Modifier.fillMaxWidth(),
        contentAlignment = if (user) Alignment.CenterEnd else Alignment.CenterStart
    ) {
        Surface(
            color = if (user) MaterialTheme.colorScheme.primaryContainer
            else MaterialTheme.colorScheme.surfaceContainerHigh,
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier.widthIn(max = 320.dp)
        ) {
            SelectionContainer {
                Text(
                    if (m.content.isEmpty() && pending) "…" else m.content,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
                )
            }
        }
    }
}

@Composable
fun SettingsDialog(vm: ChatVM, onClose: () -> Unit) {
    var key by remember { mutableStateOf(vm.apiKey) }
    var base by remember { mutableStateOf(vm.baseUrl) }
    var model by remember { mutableStateOf(vm.model) }

    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Настройки") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    key, { key = it },
                    label = { Text("API-ключ") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    base, { base = it },
                    label = { Text("Адрес API") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    model, { model = it },
                    label = { Text("Модель") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("auto", "fast").forEach { m ->
                        FilterChip(selected = model == m, onClick = { model = m }, label = { Text(m) })
                    }
                }
                TextButton(
                    onClick = { vm.loadModels(base, key) },
                    enabled = key.isNotBlank() && !vm.loadingModels
                ) { Text(if (vm.loadingModels) "Загрузка…" else "Список моделей") }
                vm.modelsError?.let {
                    Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
                if (vm.models.isNotEmpty()) {
                    LazyColumn(Modifier.heightIn(max = 180.dp)) {
                        items(vm.models) { m ->
                            Text(
                                m,
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { model = m }
                                    .padding(vertical = 8.dp)
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { vm.saveSettings(key, base, model); onClose() }) { Text("Сохранить") }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("Отмена") } }
    )
}
