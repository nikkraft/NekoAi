package com.neko.arena

import android.app.Application
import android.net.Uri
import android.util.Base64
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

class ChatVM(app: Application) : AndroidViewModel(app) {
    private val appCtx: Application = app
    private val store = Store(app)

    var chats by mutableStateOf(store.loadChats().sortedByDescending { it.updated })
        private set
    var currentId by mutableStateOf<String?>(null)
        private set
    var streaming by mutableStateOf(false)
        private set
    var error by mutableStateOf<String?>(null)

    var providers by mutableStateOf(store.loadProviders())
        private set
    var activeId by mutableStateOf<String?>(null)
        private set
    var system by mutableStateOf(store.system)
        private set

    var models by mutableStateOf<List<String>>(emptyList())
        private set
    var loadingModels by mutableStateOf(false)
        private set
    var modelsError by mutableStateOf<String?>(null)
        private set

    var pendingImages by mutableStateOf<List<String>>(emptyList())
        private set
    var pendingFiles by mutableStateOf<List<FileAtt>>(emptyList())
        private set

    private var job: Job? = null

    init {
        val saved = store.activeId
        activeId = providers.find { it.id == saved }?.id ?: providers.firstOrNull()?.id
    }

    val current: Chat? get() = chats.find { it.id == currentId }
    val active: Provider? get() = providers.find { it.id == activeId }

    // ---------- провайдеры ----------

    fun saveProvider(p: Provider) {
        val exists = providers.any { it.id == p.id }
        providers = if (exists) providers.map { if (it.id == p.id) p else it } else providers + p
        store.saveProviders(providers)
        if (!exists) selectProvider(p.id)
    }

    fun deleteProvider(id: String) {
        providers = providers.filter { it.id != id }
        store.saveProviders(providers)
        if (activeId == id) selectProvider(providers.firstOrNull()?.id)
    }

    fun selectProvider(id: String?) {
        activeId = id
        store.activeId = id ?: ""
    }

    fun setModel(id: String, m: String) {
        providers = providers.map { if (it.id == id) it.copy(model = m.trim()) else it }
        store.saveProviders(providers)
    }

    fun saveSystem(s: String) {
        store.system = s
        system = store.system
    }

    fun clearModels() {
        models = emptyList()
        modelsError = null
    }

    fun loadModels(p: Provider) {
        loadingModels = true
        modelsError = null
        viewModelScope.launch {
            try {
                models = Api.models(p)
            } catch (e: Exception) {
                modelsError = e.message ?: "Не удалось загрузить список"
            } finally {
                loadingModels = false
            }
        }
    }

    // ---------- чаты ----------

    fun newChat() {
        stop()
        currentId = null
        error = null
    }

    fun open(id: String) {
        stop()
        currentId = id
        error = null
    }

    fun delete(id: String) {
        val c = chats.find { it.id == id }
        if (id == currentId) {
            stop()
            currentId = null
        }
        chats = chats.filter { it.id != id }
        c?.messages?.flatMap { it.images }?.forEach { Attach.delete(appCtx, it) }
        persist()
    }

    fun rename(id: String, title: String) {
        val t = title.trim()
        if (t.isEmpty()) return
        chats = chats.map { if (it.id == id) it.copy(title = t) else it }
        persist()
    }

    fun stop() {
        job?.cancel()
    }

    // ---------- вложения ----------

    fun addAttachments(uris: List<Uri>) {
        if (uris.isEmpty()) return
        viewModelScope.launch {
            for (u in uris) {
                when (val r = withContext(Dispatchers.IO) { Attach.process(appCtx, u) }) {
                    is Attach.Res.Img -> {
                        if (pendingImages.size < 6) {
                            pendingImages = pendingImages + r.name
                        } else {
                            Attach.delete(appCtx, r.name)
                            error = "Не больше 6 изображений в одном сообщении"
                        }
                    }
                    is Attach.Res.Txt -> pendingFiles = pendingFiles + r.file
                    is Attach.Res.Err -> error = r.msg
                }
            }
        }
    }

    fun removePendingImage(name: String) {
        pendingImages = pendingImages - name
        Attach.delete(appCtx, name)
    }

    fun removePendingFile(f: FileAtt) {
        pendingFiles = pendingFiles - f
    }

    // ---------- отправка ----------

    private fun ready(): Provider? {
        val p = active
        if (p == null) {
            error = "Добавь провайдера: меню → Провайдеры"
            return null
        }
        if (p.model.isBlank()) {
            error = "Выбери модель: кнопка сверху"
            return null
        }
        return p
    }

    /** true, если сообщение отправлено */
    fun send(text: String): Boolean {
        val t = text.trim()
        if (streaming) return false
        if (t.isEmpty() && pendingImages.isEmpty() && pendingFiles.isEmpty()) return false
        val p = ready() ?: return false
        val id = currentId ?: UUID.randomUUID().toString()
        currentId = id
        val old = chats.find { it.id == id }
        val userMsg = Msg("user", t, pendingImages, pendingFiles)
        pendingImages = emptyList()
        pendingFiles = emptyList()
        val history = (old?.messages ?: emptyList()) + userMsg
        val title = old?.title
            ?: t.take(40).ifEmpty { userMsg.files.firstOrNull()?.name ?: "Изображение" }
        startStream(p, id, title, history)
        return true
    }

    /** Повторить последний ответ */
    fun regenerate() {
        val c = current ?: return
        if (streaming) return
        val p = ready() ?: return
        val i = c.messages.indexOfLast { it.role == "user" }
        if (i < 0) return
        startStream(p, c.id, c.title, c.messages.take(i + 1))
    }

    /** Забрать последнее сообщение пользователя на редактирование; возвращает его текст */
    fun editLast(): String? {
        val c = current ?: return null
        if (streaming) return null
        val i = c.messages.indexOfLast { it.role == "user" }
        if (i < 0) return null
        val m = c.messages[i]
        pendingImages = m.images + pendingImages
        pendingFiles = m.files + pendingFiles
        chats = chats.map { if (it.id == c.id) it.copy(messages = it.messages.take(i)) else it }
        persist()
        return m.content
    }

    private fun readImage(fn: String): String? {
        val f = Attach.file(appCtx, fn)
        return if (f.exists()) Base64.encodeToString(f.readBytes(), Base64.NO_WRAP) else null
    }

    private fun startStream(p: Provider, id: String, title: String, history: List<Msg>) {
        error = null
        val chat = Chat(id, title, history + Msg("assistant", ""), System.currentTimeMillis())
        chats = listOf(chat) + chats.filter { it.id != id }
        persist()
        streaming = true
        val sb = StringBuilder()
        job = viewModelScope.launch {
            try {
                Api.stream(p, p.model, system, history, ::readImage).collect { d ->
                    sb.append(d)
                    setAssistant(id, sb.toString())
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                error = e.message ?: "Ошибка сети"
            } finally {
                streaming = false
                finish(id, sb.isEmpty())
            }
        }
    }

    private fun setAssistant(id: String, text: String) {
        chats = chats.map {
            if (it.id == id) it.copy(messages = it.messages.dropLast(1) + Msg("assistant", text)) else it
        }
    }

    private fun finish(id: String, emptyAnswer: Boolean) {
        if (emptyAnswer) {
            chats = chats.map { c ->
                val last = c.messages.lastOrNull()
                if (c.id == id && last != null && last.role == "assistant" && last.content.isEmpty())
                    c.copy(messages = c.messages.dropLast(1))
                else c
            }
        }
        persist()
    }

    private fun persist() {
        val snapshot = chats
        viewModelScope.launch(Dispatchers.IO) { store.saveChats(snapshot) }
    }
}
