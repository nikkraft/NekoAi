package com.neko.arena

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.util.UUID

class ChatVM(app: Application) : AndroidViewModel(app) {
    private val store = Store(app)

    var chats by mutableStateOf(store.loadChats().sortedByDescending { it.updated })
        private set
    var currentId by mutableStateOf<String?>(null)
        private set
    var streaming by mutableStateOf(false)
        private set
    var error by mutableStateOf<String?>(null)

    var apiKey by mutableStateOf(store.apiKey)
        private set
    var baseUrl by mutableStateOf(store.baseUrl)
        private set
    var model by mutableStateOf(store.model)
        private set

    var models by mutableStateOf<List<String>>(emptyList())
        private set
    var loadingModels by mutableStateOf(false)
        private set
    var modelsError by mutableStateOf<String?>(null)
        private set

    private var job: Job? = null

    val current: Chat? get() = chats.find { it.id == currentId }

    fun saveSettings(key: String, base: String, m: String) {
        store.apiKey = key
        store.baseUrl = base
        store.model = m
        apiKey = store.apiKey
        baseUrl = store.baseUrl
        model = store.model
    }

    fun loadModels(base: String, key: String) {
        loadingModels = true
        modelsError = null
        viewModelScope.launch {
            try {
                val b = base.trim().trimEnd('/').ifEmpty { Store.DEFAULT_BASE }
                models = Api.models(b, key.trim())
            } catch (e: Exception) {
                modelsError = e.message ?: "Не удалось загрузить список"
            } finally {
                loadingModels = false
            }
        }
    }

    fun newChat() {
        stop()
        currentId = null
        error = null
    }

    fun open(id: String) {
        stop()
        currentId = id
        error = null
    }

    fun delete(id: String) {
        if (id == currentId) {
            stop()
            currentId = null
        }
        chats = chats.filter { it.id != id }
        persist()
    }

    fun stop() {
        job?.cancel()
    }

    /** true, если сообщение отправлено */
    fun send(text: String): Boolean {
        val t = text.trim()
        if (streaming || t.isEmpty()) return false
        if (apiKey.isBlank()) {
            error = "Укажи API-ключ в настройках"
            return false
        }
        error = null
        val id = currentId ?: UUID.randomUUID().toString()
        currentId = id
        val old = chats.find { it.id == id }
        val history = (old?.messages ?: emptyList()) + Msg("user", t)
        val chat = Chat(id, old?.title ?: t.take(40), history + Msg("assistant", ""), System.currentTimeMillis())
        chats = listOf(chat) + chats.filter { it.id != id }
        persist()
        streaming = true
        val sb = StringBuilder()
        job = viewModelScope.launch {
            try {
                Api.stream(baseUrl, apiKey, model, history).collect { d ->
                    sb.append(d)
                    setAssistant(id, sb.toString())
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                error = e.message ?: "Ошибка сети"
            } finally {
                streaming = false
                finish(id, sb.isEmpty())
            }
        }
        return true
    }

    private fun setAssistant(id: String, text: String) {
        chats = chats.map {
            if (it.id == id) it.copy(messages = it.messages.dropLast(1) + Msg("assistant", text)) else it
        }
    }

    private fun finish(id: String, emptyAnswer: Boolean) {
        if (emptyAnswer) {
            chats = chats.map { c ->
                val last = c.messages.lastOrNull()
                if (c.id == id && last != null && last.role == "assistant" && last.content.isEmpty())
                    c.copy(messages = c.messages.dropLast(1))
                else c
            }
        }
        persist()
    }

    private fun persist() {
        val snapshot = chats
        viewModelScope.launch(Dispatchers.IO) { store.saveChats(snapshot) }
    }
}
