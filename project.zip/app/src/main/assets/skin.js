/* NekoAI skin.js — правится вручную; после правки пересобери приложение.
   Приложение кладёт CSS в window.__NEKO_CSS и запускает этот файл на каждой странице. */
var BRAND = "NekoAI";
var HAS = /LM ?Arena|Arena/;
var REPLACE = /LM ?Arena|Arena/g;
// Названия меняются только в шапке, меню, подвале, заголовках и кнопках — не в тексте чатов.
var SCOPE = 'header, nav, aside, footer, [role="banner"], [role="navigation"], h1, button';
var SKIP = 'textarea, input, pre, code, [contenteditable="true"]';
var LOGO = "data:image/svg+xml;utf8," + encodeURIComponent(
  '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 108 108">' +
  '<rect width="108" height="108" rx="24" fill="#3B2E8F"/>' +
  '<path fill="#fff" d="M34,38 h40 a6,6 0 0 1 6,6 v24 a6,6 0 0 1 -6,6 h-26 l-10,9 v-9 h-4 a6,6 0 0 1 -6,-6 v-24 a6,6 0 0 1 6,-6 z"/>' +
  '</svg>');

var S = window.__NEKO_STATE || (window.__NEKO_STATE = { timer: 0, observer: null });

function ensureStyle() {
  var root = document.head || document.documentElement;
  if (!root) return;
  var st = document.getElementById("neko-skin");
  if (!st) {
    st = document.createElement("style");
    st.id = "neko-skin";
    root.appendChild(st);
  }
  if (st.textContent !== window.__NEKO_CSS) st.textContent = window.__NEKO_CSS;
}

function walk(root) {
  var w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, null);
  var n;
  while ((n = w.nextNode())) {
    var v = n.nodeValue;
    if (v && v.length < 80 && HAS.test(v)) {
      var p = n.parentElement;
      if (!(p && p.closest(SKIP))) n.nodeValue = v.replace(REPLACE, BRAND);
    }
  }
}

function rename() {
  if (document.title && HAS.test(document.title)) {
    document.title = document.title.replace(REPLACE, BRAND);
  }
  document.querySelectorAll(SCOPE).forEach(walk);
}

function logos() {
  document.querySelectorAll('header img, nav img, aside img, [role="banner"] img').forEach(function (im) {
    if (im.dataset.nekoLogo) return;
    var base = (im.src || "").split("?")[0].split("/").pop();
    if (/arena|logo/i.test((im.alt || "") + " " + base)) {
      im.dataset.nekoLogo = "1";
      im.removeAttribute("srcset");
      im.src = LOGO;
      im.alt = BRAND;
    }
  });
}

function headTags() {
  if (!document.head) return;
  document.querySelectorAll('link[rel~="icon"]').forEach(function (l) {
    if (l.getAttribute("href") !== LOGO) l.setAttribute("href", LOGO);
  });
}

function apply() {
  try {
    ensureStyle();
    rename();
    logos();
    headTags();
  } catch (e) {}
}

function schedule() {
  if (S.timer) return;
  S.timer = setTimeout(function () { S.timer = 0; apply(); }, 200);
}

if (document.documentElement) {
  apply();
  if (!S.observer) {
    S.observer = new MutationObserver(schedule);
    S.observer.observe(document.documentElement, { childList: true, subtree: true, characterData: true });
  }
}
